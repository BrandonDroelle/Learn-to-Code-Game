<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="Grass" tilewidth="64" tileheight="64" tilecount="80" columns="10">
 <image source="../../graphics/environment/Grass.png" width="640" height="512"/>
 <tile id="0" probability="0.01"/>
 <tile id="1" probability="0.01"/>
 <tile id="2" probability="0.01"/>
 <tile id="3" probability="0.01"/>
 <tile id="4" probability="0.01"/>
 <tile id="5" probability="0.01"/>
 <tile id="10" probability="0.01"/>
 <tile id="11" probability="0.01"/>
 <tile id="12" probability="0.01"/>
 <tile id="13" probability="0.01"/>
 <tile id="14" probability="0.01"/>
 <tile id="15" probability="0.01"/>
</tileset>
